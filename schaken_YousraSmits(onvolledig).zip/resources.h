//
// Created by Toon on 08/12/2017.
//

#ifndef SCHAKEN_RESOURCES_H
#define SCHAKEN_RESOURCES_H

const char* path="../resources/";  // pad, relatief ten opzichte van de executable
                                   // hier bevinden de speelfiguren zich

#endif //SCHAKEN_RESOURCES_H
